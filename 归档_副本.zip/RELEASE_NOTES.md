# LumaReader 0.9.17

Verified source commit: `755692493ca29a4be38fa6bbd7fc1828b8466458`.

CI: https://github.com/niuyajie520/LumaReader/actions/runs/42316245099

Requires macOS 26+ on Apple Silicon. Includes the application ZIP and complete source ZIP/TAR.GZ.

Debug, Swift tests, Release, signature, ARM64 and real process launch were checked. The application is ad-hoc signed, not Apple-notarized. GUI interaction, WebKit fault injection, Instruments and M4 Air performance: NOT RUN.

Release packaging removes debug symbols before signing; privacy and secret scans remain enabled.
