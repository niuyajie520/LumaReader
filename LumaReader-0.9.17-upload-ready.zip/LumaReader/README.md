# LumaReader

macOS 26+ native reader. Current source baseline: 0.9.17.

## Verification

The initial public repository contained a README and two YAML files at its root; it had no source tree and no Actions runs. This branch imports the previously delivered source and places the workflow under `.github/workflows/`.

The workflow uses `macos-26` ARM64, checks source and privacy boundaries, builds Debug, runs Swift tests, builds the Release app, and verifies its ad-hoc signature and architecture. Native UI, WebKit fault injection and M4 Air performance are separate checks and are not implied by a successful build.

On a Mac: fully extract the source, run `Verify-LumaReader.command`, then `Install-LumaReader.command`. Logs remain local. Existing app installations are backed up. No book library reset is required.

## Privacy

No real library, AI conversation, credentials, old audit reports or local build logs are included. Test text is synthetic. Existing icon PNG textual metadata is removed without changing pixel data. Gitleaks v8.30.1 scans source/history in CI; a supplemental path/PII gate runs before submission and artifact upload. Only filtered evidence is uploaded. No raw crash dumps, dSYM or unreviewed app binary artifacts are published automatically.

This is not a complete privacy guarantee or GUI certification. Previous portable PASS evidence is retained separately; it was not a macOS native test and has no associated Git commit.

## Current limitations

3D page curl remains an experimental option that falls back to the original native page turn. AI messages survive panel closure within the session but are not persisted across application restart. GPU utilization and watts without reliable public measurements remain Not Available. Source and native CI fixes on this branch do not redesign the reader, themes or AI controls.

See LICENSE and THIRD_PARTY_NOTICES.md for the project and dependencies.
